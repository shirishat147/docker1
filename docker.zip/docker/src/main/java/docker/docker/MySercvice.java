package docker.docker;

import org.springframework.stereotype.Service;

@Service
public class MySercvice {
	public int add(int a,int b)
	{
		return a+b;
	}
	public int mul(int a,int b) {
		return a*b;
	}


}
